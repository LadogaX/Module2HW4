﻿using System.Collections.Generic;
using Module2HW4.Models;
using Module2HW4.Services.Abstractions;

namespace Module2HW4.Services.Comparer
{
    public class AnimalsNameComparer : IComparer<Animals>
    {
        public int Compare(Animals animals1, Animals animals2)
        {
            return string.Compare(animals1.Name, animals2.Name);
        }
    }
}
