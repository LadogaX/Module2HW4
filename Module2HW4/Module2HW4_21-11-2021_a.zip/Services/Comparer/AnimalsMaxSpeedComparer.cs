﻿using System.Collections.Generic;
using Module2HW4.Models;

namespace Module2HW4.Services.Comparer
{
   public class AnimalsMaxSpeedComparer : IComparer<Animals>
    {
        public int Compare(Animals animals1, Animals animals2)
        {
            if (animals1.MaxSpeed > animals2.MaxSpeed)
            {
                return 1;
            }
            else if (animals1.MaxSpeed < animals2.MaxSpeed)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
