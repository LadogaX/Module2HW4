﻿namespace Module2HW4.Services.Abstractions
{
    public interface IAnimals
    {
       string Name { get; set; }
       int MaxSpeed { get; set; }
    }
}