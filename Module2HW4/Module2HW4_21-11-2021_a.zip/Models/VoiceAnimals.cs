﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2HW4.Models
{
    public enum VoiceAnimals
    {
        Barking,
        Houl,
        Squeake,
        Growl
    }
}
