﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2HW4.Models
{
    public abstract class Mices : Rodens
    {
        public bool NightLifeStyle { get; set; } = true;
    }
}
