﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2HW4.Helpers
{
        public class Result
        {
            public bool Status { get; set; }
            public string Message { get; set; }
        }
}
