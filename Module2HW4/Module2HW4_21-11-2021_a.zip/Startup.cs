﻿using System;
using System.Collections;
using System.Collections.Generic;
using Module2HW4.Helpers;
using Module2HW4.Models;
using Module2HW4.Services;
using Module2HW4.Services.Abstractions;
using Module2HW4.Services.Comparer;

namespace Module2HW4
{
    public class Startup
    {
        private readonly IZooService _zooService;
        public Startup(IZooService zooService)
        {
            _zooService = zooService;
        }

        public void Run()
        {
            AddingAnimalsInZoo();
            _zooService.DisplayZoo();
            _zooService.Sort(new AnimalsNameComparer());
            _zooService.DisplayZoo();
            _zooService.Sort(new AnimalsMaxSpeedComparer());
            _zooService.DisplayZoo();

            var result = _zooService.GetZoo().FindAnimalForName("Caracal");
            Console.WriteLine(result.Message);
        }

        public void AddingAnimalsInZoo()
        {
            _zooService.Add(new Coyote());
            _zooService.Add(new Fox());
            _zooService.Add(new Cheetah());
            _zooService.Add(new Caracal());
            _zooService.Add(new Hare());
            _zooService.Add(new WildRabbit());
            _zooService.Add(new Mice());
            _zooService.Add(new Rat());
        }
    }
}
